package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.*;

public class Common {
	public WebDriver d;

	@Parameters("webBrowser")
	@BeforeMethod
	public void launchBrowser(String webBrowser)
	{
		
		
		//Launch browser
				if(webBrowser.equals("FF"))
				{
					System.setProperty("webdriver.gecko.driver","F:\\Driver Server\\geckodriver.exe");
					d=new FirefoxDriver();
				}
				else if(webBrowser.equals("GC"))
				{
					System.setProperty("webdriver.chrome.driver","/Users/santoshbhise/Desktop/ChromeDriver");	
					d=new ChromeDriver();
				}
				else if(webBrowser.equals("IE"))
				{
					System.setProperty("webdriver.ie.driver", "F:\\Driver Server\\IEDriverServer.exe");
					d=new InternetExplorerDriver();
				}
		d.manage().window().maximize();
		
		
	}
	
	@AfterMethod
	public void killBrowser() throws InterruptedException
	{
		 Thread.sleep(5000);
		 d.quit();
	}
}
