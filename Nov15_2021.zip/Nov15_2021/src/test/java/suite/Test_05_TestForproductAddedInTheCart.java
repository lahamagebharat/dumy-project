package suite;

import base.Common;

import org.testng.Assert;
import org.testng.annotations.*;

import pages.HomePage;
import pages.LoginPage;

public class Test_05_TestForproductAddedInTheCart extends Common {

	
	@Test
	void loginScript() throws InterruptedException
	{
		d.get("https://www.saucedemo.com/");
	
	LoginPage objLoginPage=new LoginPage(d);
	HomePage objHomePage=new HomePage(d);
	
	objLoginPage.enterUsername("standard_user");
	objLoginPage.enterPassword("secret_sauce");
	objLoginPage.clickOnLoginButton();

	objHomePage.clickOnAddtocartMethod();
	
	System.out.println(objHomePage.cartCount.getText());
	
	//int cartcount=Integer.parseInt(objHomePage.cartCount.getText());
	//Assert.assertEquals(cartcount,1);
	
	Assert.assertEquals(objHomePage.cartCount.getText(), "1");
	
	 Thread.sleep(2000);
	
}


}
