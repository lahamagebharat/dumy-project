package suite;


import base.Common;

import org.testng.Assert;
import org.testng.annotations.*;

import pages.LoginPage;

public class Test_03_TestForPasswordRequiredErrorMessage extends Common {

	
	@Test
	void loginScript() throws InterruptedException
	{
		d.get("https://www.saucedemo.com/");
	
	LoginPage objLoginPage=new LoginPage(d);

	objLoginPage.enterUsername("myusername");
	
	objLoginPage.clickOnLoginButton();
	
	Assert.assertTrue(d.getPageSource().contains("Password is required"));
	
	 Thread.sleep(2000);
	
}


}
